package org.newest.runwords;

public class Utils {

    public static final String FIRST_CHANNEL_ID = "first_channel_id";
    public static final String FIRST_CHANNEL_NAME = "First Notification";
    public static final String FIRST_CHANNEL_DESC = "First Description";
}
